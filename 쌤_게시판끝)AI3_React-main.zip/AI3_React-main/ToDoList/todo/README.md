# To Do List - Spring Boot 
1. todos 테이블 생성
2. domain
    - Todos.java 
3. mapper
    - BaseMapper.java
    - TodoMapper.xml
    - TodoMapper.java
4. service
    - BaseService.java
    - TodoService.java
    - TodoServiceImpl.java
5. controller
    - TodoController.java
6. Pagination

7. OpenAPI Config

8. Data Source 

9. MyBatis Config

10. HomeController.java
    - 🔗 / : (redirect) ➡ /swagger-ui/index.html 