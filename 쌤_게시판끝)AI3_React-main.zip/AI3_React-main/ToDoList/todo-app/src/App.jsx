import './App.css'
import React from 'react'
import Container from './Components/Todo/Container'

const App = () => {
  return (
    <>
      <Container />
    </>
  )
}

export default App