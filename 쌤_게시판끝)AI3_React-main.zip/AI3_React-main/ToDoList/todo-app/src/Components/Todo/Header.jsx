import React from 'react'

const Header = () => {
  return (
    <div className="header">
        <h1>To do List</h1>
    </div>
  )
}

export default Header