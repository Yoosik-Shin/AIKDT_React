import './App.css'
import ProductDetail from './Components/ProductDetail'

const App = () => {
  return (
    <>
      <ProductDetail />
    </>
  )
}

export default App