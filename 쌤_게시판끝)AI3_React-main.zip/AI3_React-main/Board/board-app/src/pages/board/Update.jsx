import React from 'react'
import UpdateContainer from '../../containers/board/UpdateContainer'

const Update = () => {
  return (
    <>
      <UpdateContainer />
    </>
  )
}

export default Update