# 라이브러리
npm install react-router-dom axios


### mui icon
npm install @mui/icons-material @mui/material @emotion/react @emotion/styled


### ckeditor
npm install --save @ckeditor/ckeditor5-react 
npm install --save @ckeditor/ckeditor5-build-classic
npm install --save @ckeditor/ckeditor5-alignment