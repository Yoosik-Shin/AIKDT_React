package com.aloha.board.service;

import com.aloha.board.domain.Boards;

public interface BoardService extends BaseService<Boards> {
    
}
