package com.aloha.board.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.aloha.board.domain.Boards;

@Mapper
public interface BoardMapper extends BaseMapper<Boards> {
    
}
